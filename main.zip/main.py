import telebot
import requests
import urllib.request as urllib2
from bs4 import BeautifulSoup, SoupStrainer
from pornhub_api import PornhubApi
import random
api = PornhubApi()

tags = random.sample(api.video.tags("f").tags, 5)
category = random.choice(api.video.categories().categories)
result = api.search.search_videos(ordering="mostviewed", tags=tags, category=category)

print(result.size())
for vid in result:
    f = open('database.txt', 'a')
    f.write(vid.url)

f.close()